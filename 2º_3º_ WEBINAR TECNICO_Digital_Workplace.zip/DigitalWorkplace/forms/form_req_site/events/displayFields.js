function displayFields(form,customHTML){
	
	var activity = getValue('WKNumState');
	var user    =  getValue('WKUser');
    if (activity == 19 ) {
    	
    	//Obtem os valores dos campos
    	var nome = form.getValue("name");
    	var email = form.getValue("email");
    	var tel   = form.getValue("phone");
    	var req   = form.getValue("request");
    	var msg   = form.getValue("message");
    	
    	var interacao = '<p>Oi <span id=usrProcess></span>, o <b>'+nome+'</b> nao esta muito contente com alguma situacao, ele escreveu isso pra gente atraves do site :<br><i> '+msg+'.</i> Vamos entender o porque ele esta com esta insatisfacao? <br> Ele deixou esse telefone pra contato : <b>'+tel+'</b> e o email dele e : '+email+'. Obrigado ;) </p>'
    	
    	var txtInteracao  = '<h1>Oi <span class=txt_destaq id=usrProcess></span></h1>';
    		txtInteracao += '<p>O <span class=txt_destaq_sub>'+nome+'</span> nao esta muito contente com alguma situacao, ele escreveu isso pra gente atraves do site :<br>';
    		txtInteracao += '<i>'+msg+'</i><br>';
    		txtInteracao += 'Vamos entender o porque ele esta com esta insatisfacao? <br> Ele deixou esse telefone pra contato : <span class=txt_destaq_sub>'+tel+'</span> e o email dele e : <span class=txt_destaq_sub>'+email+'</span>.';
    		txtInteracao += '<span class=txt_destaq>Obrigado ;)<span>';
    		
    		
    	customHTML.append('<script>$("#messageInteracao").append("'+txtInteracao+'")</script>');
    	customHTML.append('<script>$("#usrProcess").text("'+user+'"); $("#messageInteracao").show(); $("#formPrincipal").hide();</script>');
	
    }
    
    
 if (activity == 14 ) {
    	
    	//Obtem os valores dos campos
    	var nome = form.getValue("name");
    	var email = form.getValue("email");
    	var tel   = form.getValue("phone");
    	var req   = form.getValue("request");
    	var msg   = form.getValue("message");
    	
    	//var interacao = '<p>Oi <span id=usrProcess></span>, o <b>'+nome+'</b> sugeriu algo pra gente atraves do site :<br><i> '+msg+'.</i> Vamos analisar esta sugestao e quem sabe nao podemos melhorar nossos servicos? <br> Ele deixou esse telefone pra contato : <b>'+tel+'</b> e o email dele e : '+email+'. Obrigado ;) </p>'
    	
    	var txtInteracao  = '<h1>Oi <span class=txt_destaq id=usrProcess></span></h1>';
    		txtInteracao += '<p>O <span class=txt_destaq_sub>'+nome+'</span> sugeriu algo pra gente atraves do site :<br>';
    		txtInteracao += '<i>'+msg+'</i><br>';
    		txtInteracao += 'Vamos analisar esta sugestao e quem sabe nao possamos melhorar nossos servicos? <br> Ele deixou esse telefone pra contato : <span class=txt_destaq_sub>'+tel+'</span> e o email dele e : <span class=txt_destaq_sub>'+email+'</span>.<br>';
    		txtInteracao += '<span class=txt_destaq>Obrigado ;)<span>';
    		
    		
    	customHTML.append('<script>$("#messageInteracao").append("'+txtInteracao+'")</script>');
    	customHTML.append('<script>$("#usrProcess").text("'+user+'"); $("#messageInteracao").show(); $("#formPrincipal").hide();</script>');
	
    }
	
}