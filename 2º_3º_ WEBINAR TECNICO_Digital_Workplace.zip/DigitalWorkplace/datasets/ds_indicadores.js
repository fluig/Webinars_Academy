function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	var nome_dataset = "ds_Form_req_site"	
	var dataset = DatasetBuilder.newDataset();
	//Cria as colunas
	dataset.addColumn("Codigo");
   
    
    var dsIndicadores = DatasetFactory.getDataset(nome_dataset, null,null,null);
        for (i = 0;  i < dsIndicadores.rowsCount; i++){
    		dataset.addRow(new Array(dsIndicadores.getValue(i,"request")));
    	}
    
    return dataset;
	

}function onMobileSync(user) {

}