function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	var nome_dataset = "ds_Form_req_site"
	var dataset = DatasetBuilder.newDataset();
	
	//Cria as colunas
	dataset.addColumn("Nome");
    dataset.addColumn("mensagens");
    dataset.addColumn("login");
    dataset.addColumn("data_request");
    dataset.addColumn("request");
    
        
   var dsUser = DatasetFactory.getDataset(nome_dataset, null,null,null);
    
    for (i = 0;  i < dsUser.rowsCount; i++){
    	
    	dataset.addRow(new Array(dsUser.getValue(i,"name"), dsUser.getValue(i,"message"), dsUser.getValue(i,"login"), dsUser.getValue(i,"date_request"),dsUser.getValue(i,"request") ));
    	
    	
    }
   
        
    return dataset;
	

}function onMobileSync(user) {

}