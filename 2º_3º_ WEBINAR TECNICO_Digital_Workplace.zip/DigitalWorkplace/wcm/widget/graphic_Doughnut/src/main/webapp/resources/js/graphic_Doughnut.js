var Doughnut = SuperWidget.extend({
    //variáveis da widget
    variavelNumerica: null,
    variavelCaracter: null,

    //método iniciado quando a widget é carregada
    init: function() {
    	
    	// consulta um dataset customizado
    	var ds = DatasetFactory.getDataset("ds_indicadores",null,null,null);

        var sugestao = 0;
        var reclamacao = 0;
        var orcamento = 0;
     // popula o array 
        for (x = 0; x < ds.values.length; x++){
        	
        	if (ds.values[x]["Codigo"] == 1){
        		reclamacao = reclamacao + 1;
        	}else if (ds.values[x]["Codigo"] == 2 ){
        		sugestao = sugestao + 1;
        	}else if (ds.values[x]["Codigo"] == 3){
        		orcamento = orcamento + 1;
        	}
        
        }
        
        var data = [
            {
                value: reclamacao,
                color:"#F7464A",
                highlight: "#FF5A5E",
                label: "Reclamação"
            },
            {
                value: orcamento,
                color: "#46BFBD",
                highlight: "#5AD3D1",
                label: "Orçamento"
            },
            {
                value: sugestao,
                color: "#FDB45C",
                highlight: "#FFC870",
                label: "Sugestão"
            }
        ]
        var chart = FLUIGC.chart('#grafico_2', {
            id: 'grafico',
            width: '700',
            height: '400',
            /* See the list of options */
        });
        // call the line function
        var doughnutChart = chart.doughnut(data, "");

    },
  
    //BIND de eventos
    bindings: {
        local: {
            'execute': ['click_executeAction']
        },
        global: {}
    },
 
    executeAction: function(htmlElement, event) {
    }

});

