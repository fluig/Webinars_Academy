var list_group = SuperWidget.extend({
    //variáveis da widget
    variavelNumerica: null,
    variavelCaracter: null,

    //método iniciado quando a widget é carregada
    init: function() {
    
        	// consulta um dataset customizado
        	var ds = DatasetFactory.getDataset("ds_Ultimas_Sugestoes",null,null,null);

        	var foto = null;
         // popula o array 
            for (x = 0; x < ds.values.length; x++){
            	
            	if(ds.values[x]["login"] == "Guest"){
            		foto = "<img src='/list_group/resources/images/logo_clientes.png' alt=''>";
            		
            	} else {
            		foto ="<img src='/social/api/rest/social/image/profile/"+ds.values[x]["login"]+"/MEDIUM_PICTURE' alt=''>"
            	
            	}
            		
            	$('#mensagem').append("<a href='#' class='list-group-item widget-digital-workplace'>" +  foto + 
            			"<h4 class='list-group-item-heading'>"+ ds.values[x]["Nome"] + '-' + ds.values[x]["data_request"] +"</h4>" +
            	        "<p class='list-group-item-text'>"+ ds.values[x]["mensagens"] + "</p>" +
            	    "</a>");
            		
            }
        	        	
    },
  
    //BIND de eventos
    bindings: {
        local: {
            'execute': ['click_executeAction']
        },
        global: {}
    },
 
    executeAction: function(htmlElement, event) {
    }

});

